#Lemon

![lemonchars](http://a.pomf.se/hyojpi.png)

![kvtie lemon](http://a.pomf.se/vgljse.png)

Personal mod of lime with better kerning, more distinguished characters, and powerline/icon support.


#uushi

![uushichars](http://a.pomf.se/3Cg6-983.png)

![kvtie uushi](http://a.pomf.se/8Tl3.png)

My take on Monaco. Overall, it's much less curved than lemon but still retains many of the same features and ideas (e.g, readability, icons, etc).


#Installation

To install the fonts, simply run the install script provided.

#Note on icons/powerline

To enable powerline support, be sure to set powerline symbols to 'fancy'. To use the icons, enter vim's insert mode and hold ctrl-shift (assuming urxvt); while doing so, press the corresponding number of the desired icon (shown below). For convenience, both fonts use the same unicode position for the same characters. 

UPDATE: To make things easier on everyone, I added a file in which the icons are readily available for copying and pasting. Enjoy.

![powerline](http://a.pomf.se/0Oa6.png)

![icons-lemon](http://a.pomf.se/mghqcn.png)
