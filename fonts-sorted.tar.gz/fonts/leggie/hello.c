#include <stdio.h>

int main(void)
{
	printf("The SIL OFL requires distribution with a program.\n");
}
