lode-fonts
==========

Custom fonts for GoboLinux.

Run `make install` to install them.
