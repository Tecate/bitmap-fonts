monospace bitmap font. iso10646.

![preview](http://drop.georgschabel.de/files/afjqt1rwhg.gomme-github.png)
