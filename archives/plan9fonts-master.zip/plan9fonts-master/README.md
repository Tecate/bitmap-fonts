plan9fonts
==========

Various fonts, converted to plan9 subf.


### Current fonts

* jmk/: [Neep & Modd](http://www.jmknoble.net/fonts/)
* kourier/: [Kourier & Ksans](http://www.semware.com/html/tseprofilesr.php#FONTS)
* mntcarlo/: [MonteCarlo Programmer Font](http://www.bok.net/MonteCarlo/)
* profont/: [ProFont & Sheldon](http://www.tobias-jung.de/seekingprofont/)
* proggyfnt/: [Proggy Programming Fonts](http://www.proggyfonts.com/)
* tamsyn/: [Tamsyn - Monospaced Programming Font](http://www.fial.com/~scott/tamsyn-font/)
* tamzen/: [Tamzen font](https://github.com/sunaku/tamzen-font)
* terminus/: [Terminus Font](http://terminus-font.sourceforge.net/)
* trisk/: [Triskweline](http://www.netalive.org/tinkering/triskweline/)
* uni-vga/: [UNI-VGA (Unicode VGA font)](http://www.inp.nsk.su/~bolkhov/files/fonts/univga/)
* zevv-peep/: [zevv-peep](http://zevv.nl/play/code/zevv-peep/)
